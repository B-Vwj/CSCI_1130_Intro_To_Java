# Run the program
java -classpath "." Subtract
read -p "Press enter to continue"
