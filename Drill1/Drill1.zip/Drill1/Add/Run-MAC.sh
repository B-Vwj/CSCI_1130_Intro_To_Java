# Run the program
java -classpath "." Add
read -p "Press enter to continue"
