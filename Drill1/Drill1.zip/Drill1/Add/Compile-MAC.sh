# compile (build machine code from source code)
javac -classpath "." Add.java
read -p "Press enter to continue"
