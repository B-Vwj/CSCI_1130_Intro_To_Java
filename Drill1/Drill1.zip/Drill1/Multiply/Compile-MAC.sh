# compile (build machine code from source code)
javac -classpath "." Multiply.java
read -p "Press enter to continue"
