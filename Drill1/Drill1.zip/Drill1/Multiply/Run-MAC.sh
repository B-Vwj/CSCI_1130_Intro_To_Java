# Run the program
java -classpath "." Multiply
read -p "Press enter to continue"
