public class Ball {
    int radius = 1;
    String color = "Blue";
}