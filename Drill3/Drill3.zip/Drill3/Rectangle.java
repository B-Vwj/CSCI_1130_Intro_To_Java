public class Rectangle {
    int width = 10;
    int height = 12;
}