# Run the program
# Will "run" the "RectangleTester" class (from the RectangleTester.class file)
# It will call RectangleTester's "main" method
java -classpath "." RectangleTester
read -p "Press enter to continue"
