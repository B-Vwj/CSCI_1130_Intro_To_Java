# Compile (build machine code from source code)
# This will take the "RectangleTester.java" file and build a "RectangleTester.class" file
javac -classpath "." RectangleTester.java
read -p "Press enter to continue"
