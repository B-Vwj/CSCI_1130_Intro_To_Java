# Compile (build machine code from source code)
# This will take the "Rectangle.java" file and build a "Rectangle.class" file
javac -classpath "." Rectangle.java
read -p "Press enter to continue"
